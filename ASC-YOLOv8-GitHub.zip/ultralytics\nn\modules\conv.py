# Ultralytics YOLO 🚀, AGPL-3.0 license
"""Convolution modules."""

import math
import torch.nn.functional as F
import numpy as np
import torch
import torch.nn as nn
from torchvision.ops import DeformConv2d
from einops import rearrange


__all__ = (
    "Conv",
    "Conv2",
    "LightConv",
    "DWConv",
    "DWConvTranspose2d",
    "ConvTranspose",
    "Focus",
    "GhostConv",
    "ChannelAttention",
    "SpatialAttention",
    "CBAM",
    "Concat",
    "BiFPN_Concat2",
    "BiFPN_Concat3",
    "BiFPN_Concat3",
    "RepConv",
    "LSKA",
    "GSConv",
    "GSBottleneck",
    "DWConv",
    "VoVGSCSPC",
    "VoVGSCSP",
    "SE",
    "CoordAtt",
    "AKConv",
    "GC_CoordAtt",
)


def autopad(k, p=None, d=1):  # kernel, padding, dilation
    """Pad to 'same' shape outputs."""
    if d > 1:
        k = d * (k - 1) + 1 if isinstance(k, int) else [d * (x - 1) + 1 for x in k]  # actual kernel-size
    if p is None:
        p = k // 2 if isinstance(k, int) else [x // 2 for x in k]  # auto-pad
    return p


class Conv(nn.Module):
    """Standard convolution with args(ch_in, ch_out, kernel, stride, padding, groups, dilation, activation)."""

    default_act = nn.SiLU()  # default activation

    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, d=1, act=True):
        """Initialize Conv layer with given arguments including activation."""
        super().__init__()
        self.conv = nn.Conv2d(c1, c2, k, s, autopad(k, p, d), groups=g, dilation=d, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.act = self.default_act if act is True else act if isinstance(act, nn.Module) else nn.Identity()

    def forward(self, x):
        """Apply convolution, batch normalization and activation to input tensor."""
        return self.act(self.bn(self.conv(x)))

    def forward_fuse(self, x):
        """Perform transposed convolution of 2D data."""
        return self.act(self.conv(x))


class Conv2(Conv):
    """Simplified RepConv module with Conv fusing."""

    def __init__(self, c1, c2, k=3, s=1, p=None, g=1, d=1, act=True):
        """Initialize Conv layer with given arguments including activation."""
        super().__init__(c1, c2, k, s, p, g=g, d=d, act=act)
        self.cv2 = nn.Conv2d(c1, c2, 1, s, autopad(1, p, d), groups=g, dilation=d, bias=False)  # add 1x1 conv

    def forward(self, x):
        """Apply convolution, batch normalization and activation to input tensor."""
        return self.act(self.bn(self.conv(x) + self.cv2(x)))

    def forward_fuse(self, x):
        """Apply fused convolution, batch normalization and activation to input tensor."""
        return self.act(self.bn(self.conv(x)))

    def fuse_convs(self):
        """Fuse parallel convolutions."""
        w = torch.zeros_like(self.conv.weight.data)
        i = [x // 2 for x in w.shape[2:]]
        w[:, :, i[0] : i[0] + 1, i[1] : i[1] + 1] = self.cv2.weight.data.clone()
        self.conv.weight.data += w
        self.__delattr__("cv2")
        self.forward = self.forward_fuse


class LightConv(nn.Module):
    """
    Light convolution with args(ch_in, ch_out, kernel).

    https://github.com/PaddlePaddle/PaddleDetection/blob/develop/ppdet/modeling/backbones/hgnet_v2.py
    """

    def __init__(self, c1, c2, k=1, act=nn.ReLU()):
        """Initialize Conv layer with given arguments including activation."""
        super().__init__()
        self.conv1 = Conv(c1, c2, 1, act=False)
        self.conv2 = DWConv(c2, c2, k, act=act)

    def forward(self, x):
        """Apply 2 convolutions to input tensor."""
        return self.conv2(self.conv1(x))


class DWConv(Conv):
    """Depth-wise convolution."""

    def __init__(self, c1, c2, k=1, s=1, d=1, act=True):  # ch_in, ch_out, kernel, stride, dilation, activation
        """Initialize Depth-wise convolution with given parameters."""
        super().__init__(c1, c2, k, s, g=math.gcd(c1, c2), d=d, act=act)


class DWConvTranspose2d(nn.ConvTranspose2d):
    """Depth-wise transpose convolution."""

    def __init__(self, c1, c2, k=1, s=1, p1=0, p2=0):  # ch_in, ch_out, kernel, stride, padding, padding_out
        """Initialize DWConvTranspose2d class with given parameters."""
        super().__init__(c1, c2, k, s, p1, p2, groups=math.gcd(c1, c2))


class ConvTranspose(nn.Module):
    """Convolution transpose 2d layer."""

    default_act = nn.SiLU()  # default activation

    def __init__(self, c1, c2, k=2, s=2, p=0, bn=True, act=True):
        """Initialize ConvTranspose2d layer with batch normalization and activation function."""
        super().__init__()
        self.conv_transpose = nn.ConvTranspose2d(c1, c2, k, s, p, bias=not bn)
        self.bn = nn.BatchNorm2d(c2) if bn else nn.Identity()
        self.act = self.default_act if act is True else act if isinstance(act, nn.Module) else nn.Identity()

    def forward(self, x):
        """Applies transposed convolutions, batch normalization and activation to input."""
        return self.act(self.bn(self.conv_transpose(x)))

    def forward_fuse(self, x):
        """Applies activation and convolution transpose operation to input."""
        return self.act(self.conv_transpose(x))


class Focus(nn.Module):
    """Focus wh information into c-space."""

    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, act=True):
        """Initializes Focus object with user defined channel, convolution, padding, group and activation values."""
        super().__init__()
        self.conv = Conv(c1 * 4, c2, k, s, p, g, act=act)
        # self.contract = Contract(gain=2)

    def forward(self, x):
        """
        Applies convolution to concatenated tensor and returns the output.

        Input shape is (b,c,w,h) and output shape is (b,4c,w/2,h/2).
        """
        return self.conv(torch.cat((x[..., ::2, ::2], x[..., 1::2, ::2], x[..., ::2, 1::2], x[..., 1::2, 1::2]), 1))
        # return self.conv(self.contract(x))


class GhostConv(nn.Module):
    """Ghost Convolution https://github.com/huawei-noah/ghostnet."""

    def __init__(self, c1, c2, k=1, s=1, g=1, act=True):
        """Initializes Ghost Convolution module with primary and cheap operations for efficient feature learning."""
        super().__init__()
        c_ = c2 // 2  # hidden channels
        self.cv1 = Conv(c1, c_, k, s, None, g, act=act)
        self.cv2 = Conv(c_, c_, 5, 1, None, c_, act=act)

    def forward(self, x):
        """Forward propagation through a Ghost Bottleneck layer with skip connection."""
        y = self.cv1(x)
        return torch.cat((y, self.cv2(y)), 1)


class RepConv(nn.Module):
    """
    RepConv is a basic rep-style block, including training and deploy status.

    This module is used in RT-DETR.
    Based on https://github.com/DingXiaoH/RepVGG/blob/main/repvgg.py
    """

    default_act = nn.SiLU()  # default activation

    def __init__(self, c1, c2, k=3, s=1, p=1, g=1, d=1, act=True, bn=False, deploy=False):
        """Initializes Light Convolution layer with inputs, outputs & optional activation function."""
        super().__init__()
        assert k == 3 and p == 1
        self.g = g
        self.c1 = c1
        self.c2 = c2
        self.act = self.default_act if act is True else act if isinstance(act, nn.Module) else nn.Identity()

        self.bn = nn.BatchNorm2d(num_features=c1) if bn and c2 == c1 and s == 1 else None
        self.conv1 = Conv(c1, c2, k, s, p=p, g=g, act=False)
        self.conv2 = Conv(c1, c2, 1, s, p=(p - k // 2), g=g, act=False)

    def forward_fuse(self, x):
        """Forward process."""
        return self.act(self.conv(x))

    def forward(self, x):
        """Forward process."""
        id_out = 0 if self.bn is None else self.bn(x)
        return self.act(self.conv1(x) + self.conv2(x) + id_out)

    def get_equivalent_kernel_bias(self):
        """Returns equivalent kernel and bias by adding 3x3 kernel, 1x1 kernel and identity kernel with their biases."""
        kernel3x3, bias3x3 = self._fuse_bn_tensor(self.conv1)
        kernel1x1, bias1x1 = self._fuse_bn_tensor(self.conv2)
        kernelid, biasid = self._fuse_bn_tensor(self.bn)
        return kernel3x3 + self._pad_1x1_to_3x3_tensor(kernel1x1) + kernelid, bias3x3 + bias1x1 + biasid

    @staticmethod
    def _pad_1x1_to_3x3_tensor(kernel1x1):
        """Pads a 1x1 tensor to a 3x3 tensor."""
        if kernel1x1 is None:
            return 0
        else:
            return torch.nn.functional.pad(kernel1x1, [1, 1, 1, 1])

    def _fuse_bn_tensor(self, branch):
        """Generates appropriate kernels and biases for convolution by fusing branches of the neural network."""
        if branch is None:
            return 0, 0
        if isinstance(branch, Conv):
            kernel = branch.conv.weight
            running_mean = branch.bn.running_mean
            running_var = branch.bn.running_var
            gamma = branch.bn.weight
            beta = branch.bn.bias
            eps = branch.bn.eps
        elif isinstance(branch, nn.BatchNorm2d):
            if not hasattr(self, "id_tensor"):
                input_dim = self.c1 // self.g
                kernel_value = np.zeros((self.c1, input_dim, 3, 3), dtype=np.float32)
                for i in range(self.c1):
                    kernel_value[i, i % input_dim, 1, 1] = 1
                self.id_tensor = torch.from_numpy(kernel_value).to(branch.weight.device)
            kernel = self.id_tensor
            running_mean = branch.running_mean
            running_var = branch.running_var
            gamma = branch.weight
            beta = branch.bias
            eps = branch.eps
        std = (running_var + eps).sqrt()
        t = (gamma / std).reshape(-1, 1, 1, 1)
        return kernel * t, beta - running_mean * gamma / std

    def fuse_convs(self):
        """Combines two convolution layers into a single layer and removes unused attributes from the class."""
        if hasattr(self, "conv"):
            return
        kernel, bias = self.get_equivalent_kernel_bias()
        self.conv = nn.Conv2d(
            in_channels=self.conv1.conv.in_channels,
            out_channels=self.conv1.conv.out_channels,
            kernel_size=self.conv1.conv.kernel_size,
            stride=self.conv1.conv.stride,
            padding=self.conv1.conv.padding,
            dilation=self.conv1.conv.dilation,
            groups=self.conv1.conv.groups,
            bias=True,
        ).requires_grad_(False)
        self.conv.weight.data = kernel
        self.conv.bias.data = bias
        for para in self.parameters():
            para.detach_()
        self.__delattr__("conv1")
        self.__delattr__("conv2")
        if hasattr(self, "nm"):
            self.__delattr__("nm")
        if hasattr(self, "bn"):
            self.__delattr__("bn")
        if hasattr(self, "id_tensor"):
            self.__delattr__("id_tensor")


class ChannelAttention(nn.Module):
    """Channel-attention module https://github.com/open-mmlab/mmdetection/tree/v3.0.0rc1/configs/rtmdet."""

    def __init__(self, channels: int) -> None:
        """Initializes the class and sets the basic configurations and instance variables required."""
        super().__init__()
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Conv2d(channels, channels, 1, 1, 0, bias=True)
        self.act = nn.Sigmoid()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Applies forward pass using activation on convolutions of the input, optionally using batch normalization."""
        return x * self.act(self.fc(self.pool(x)))


class SpatialAttention(nn.Module):
    """Spatial-attention module."""

    def __init__(self, kernel_size=7):
        """Initialize Spatial-attention module with kernel size argument."""
        super().__init__()
        assert kernel_size in {3, 7}, "kernel size must be 3 or 7"
        padding = 3 if kernel_size == 7 else 1
        self.cv1 = nn.Conv2d(2, 1, kernel_size, padding=padding, bias=False)
        self.act = nn.Sigmoid()

    def forward(self, x):
        """Apply channel and spatial attention on input for feature recalibration."""
        return x * self.act(self.cv1(torch.cat([torch.mean(x, 1, keepdim=True), torch.max(x, 1, keepdim=True)[0]], 1)))


class CBAM(nn.Module):
    """Convolutional Block Attention Module."""

    def __init__(self, c1, kernel_size=7):
        """Initialize CBAM with given input channel (c1) and kernel size."""
        super().__init__()
        self.channel_attention = ChannelAttention(c1)
        self.spatial_attention = SpatialAttention(kernel_size)

    def forward(self, x):
        """Applies the forward pass through C1 module."""
        return self.spatial_attention(self.channel_attention(x))


class Concat(nn.Module):
    """Concatenate a list of tensors along dimension."""

    def __init__(self, dimension=1):
        """Concatenates a list of tensors along a specified dimension."""
        super().__init__()
        self.d = dimension

    def forward(self, x):
        """Forward pass for the YOLOv8 mask Proto module."""
        return torch.cat(x, self.d)


# 结合BiFPN 设置可学习参数 学习不同分支的权重
# 两个分支concat操作
class BiFPN_Concat2(nn.Module):
    def __init__(self, dimension=1):
        super(BiFPN_Concat2, self).__init__()
        self.d = dimension
        self.w = nn.Parameter(torch.ones(2, dtype=torch.float32), requires_grad=True)
        self.epsilon = 0.0001

    def forward(self, x):
        w = self.w
        weight = w / (torch.sum(w, dim=0) + self.epsilon)  # 将权重进行归一化
        # Fast normalized fusion
        x = [weight[0] * x[0], weight[1] * x[1]]
        return torch.cat(x, self.d)


# 三个分支concat操作
class BiFPN_Concat3(nn.Module):
    def __init__(self, dimension=1):
        super(BiFPN_Concat3, self).__init__()
        self.d = dimension
        # 设置可学习参数 nn.Parameter的作用是：将一个不可训练的类型Tensor转换成可以训练的类型parameter
        # 并且会向宿主模型注册该参数 成为其一部分 即model.parameters()会包含这个parameter
        # 从而在参数优化的时候可以自动一起优化
        self.w = nn.Parameter(torch.ones(3, dtype=torch.float32), requires_grad=True)
        self.epsilon = 0.0001

    def forward(self, x):
        w = self.w
        weight = w / (torch.sum(w, dim=0) + self.epsilon)  # 将权重进行归一化
        # Fast normalized fusion
        x = [weight[0] * x[0], weight[1] * x[1], weight[2] * x[2]]
        return torch.cat(x, self.d)



class LSKA(nn.Module):
    # Large-Separable-Kernel-Attention
    def __init__(self, dim, k_size=7):
        super().__init__()

        self.k_size = k_size

        if k_size == 7:
            self.conv0h = nn.Conv2d(dim, dim, kernel_size=(1, 3), stride=(1, 1), padding=(0, (3 - 1) // 2), groups=dim)
            self.conv0v = nn.Conv2d(dim, dim, kernel_size=(3, 1), stride=(1, 1), padding=((3 - 1) // 2, 0), groups=dim)
            self.conv_spatial_h = nn.Conv2d(dim, dim, kernel_size=(1, 3), stride=(1, 1), padding=(0, 2), groups=dim,
                                            dilation=2)
            self.conv_spatial_v = nn.Conv2d(dim, dim, kernel_size=(3, 1), stride=(1, 1), padding=(2, 0), groups=dim,
                                            dilation=2)
        elif k_size == 11:
            self.conv0h = nn.Conv2d(dim, dim, kernel_size=(1, 3), stride=(1, 1), padding=(0, (3 - 1) // 2), groups=dim)
            self.conv0v = nn.Conv2d(dim, dim, kernel_size=(3, 1), stride=(1, 1), padding=((3 - 1) // 2, 0), groups=dim)
            self.conv_spatial_h = nn.Conv2d(dim, dim, kernel_size=(1, 5), stride=(1, 1), padding=(0, 4), groups=dim,
                                            dilation=2)
            self.conv_spatial_v = nn.Conv2d(dim, dim, kernel_size=(5, 1), stride=(1, 1), padding=(4, 0), groups=dim,
                                            dilation=2)
        elif k_size == 23:
            self.conv0h = nn.Conv2d(dim, dim, kernel_size=(1, 5), stride=(1, 1), padding=(0, (5 - 1) // 2), groups=dim)
            self.conv0v = nn.Conv2d(dim, dim, kernel_size=(5, 1), stride=(1, 1), padding=((5 - 1) // 2, 0), groups=dim)
            self.conv_spatial_h = nn.Conv2d(dim, dim, kernel_size=(1, 7), stride=(1, 1), padding=(0, 9), groups=dim,
                                            dilation=3)
            self.conv_spatial_v = nn.Conv2d(dim, dim, kernel_size=(7, 1), stride=(1, 1), padding=(9, 0), groups=dim,
                                            dilation=3)
        elif k_size == 35:
            self.conv0h = nn.Conv2d(dim, dim, kernel_size=(1, 5), stride=(1, 1), padding=(0, (5 - 1) // 2), groups=dim)
            self.conv0v = nn.Conv2d(dim, dim, kernel_size=(5, 1), stride=(1, 1), padding=((5 - 1) // 2, 0), groups=dim)
            self.conv_spatial_h = nn.Conv2d(dim, dim, kernel_size=(1, 11), stride=(1, 1), padding=(0, 15), groups=dim,
                                            dilation=3)
            self.conv_spatial_v = nn.Conv2d(dim, dim, kernel_size=(11, 1), stride=(1, 1), padding=(15, 0), groups=dim,
                                            dilation=3)
        elif k_size == 41:
            self.conv0h = nn.Conv2d(dim, dim, kernel_size=(1, 5), stride=(1, 1), padding=(0, (5 - 1) // 2), groups=dim)
            self.conv0v = nn.Conv2d(dim, dim, kernel_size=(5, 1), stride=(1, 1), padding=((5 - 1) // 2, 0), groups=dim)
            self.conv_spatial_h = nn.Conv2d(dim, dim, kernel_size=(1, 13), stride=(1, 1), padding=(0, 18), groups=dim,
                                            dilation=3)
            self.conv_spatial_v = nn.Conv2d(dim, dim, kernel_size=(13, 1), stride=(1, 1), padding=(18, 0), groups=dim,
                                            dilation=3)
        elif k_size == 53:
            self.conv0h = nn.Conv2d(dim, dim, kernel_size=(1, 5), stride=(1, 1), padding=(0, (5 - 1) // 2), groups=dim)
            self.conv0v = nn.Conv2d(dim, dim, kernel_size=(5, 1), stride=(1, 1), padding=((5 - 1) // 2, 0), groups=dim)
            self.conv_spatial_h = nn.Conv2d(dim, dim, kernel_size=(1, 17), stride=(1, 1), padding=(0, 24), groups=dim,
                                            dilation=3)
            self.conv_spatial_v = nn.Conv2d(dim, dim, kernel_size=(17, 1), stride=(1, 1), padding=(24, 0), groups=dim,
                                            dilation=3)

        self.conv1 = nn.Conv2d(dim, dim, 1)

    def forward(self, x):
        u = x.clone()
        attn = self.conv0h(x)
        attn = self.conv0v(attn)
        attn = self.conv_spatial_h(attn)
        attn = self.conv_spatial_v(attn)
        attn = self.conv1(attn)
        return u * attn


class GSConv(nn.Module):
    # GSConv https://github.com/AlanLi1997/slim-neck-by-gsconv
    def __init__(self, c1, c2, k=1, s=1, g=1, act=True):
        super().__init__()
        c_ = c2 // 2
        self.cv1 = Conv(c1, c_, k, s, None, g, 1, act)
        self.cv2 = Conv(c_, c_, 5, 1, None, c_, 1, act)

    def forward(self, x):
        x1 = self.cv1(x)
        x2 = torch.cat((x1, self.cv2(x1)), 1)
        # shuffle
        # y = x2.reshape(x2.shape[0], 2, x2.shape[1] // 2, x2.shape[2], x2.shape[3])
        # y = y.permute(0, 2, 1, 3, 4)
        # return y.reshape(y.shape[0], -1, y.shape[3], y.shape[4])

        b, n, h, w = x2.data.size()
        b_n = b * n // 2
        y = x2.reshape(b_n, 2, h * w)
        y = y.permute(1, 0, 2)
        y = y.reshape(2, -1, n // 2, h, w)

        return torch.cat((y[0], y[1]), 1)


class GSConvns(GSConv):
    # GSConv with a normative-shuffle https://github.com/AlanLi1997/slim-neck-by-gsconv
    def __init__(self, c1, c2, k=1, s=1, g=1, act=True):
        super().__init__(c1, c2, k=1, s=1, g=1, act=True)
        c_ = c2 // 2
        self.shuf = nn.Conv2d(c_ * 2, c2, 1, 1, 0, bias=False)

    def forward(self, x):
        x1 = self.cv1(x)
        x2 = torch.cat((x1, self.cv2(x1)), 1)
        # normative-shuffle, TRT supported
        return nn.ReLU(self.shuf(x2))


class GSBottleneck(nn.Module):
    # GS Bottleneck https://github.com/AlanLi1997/slim-neck-by-gsconv
    def __init__(self, c1, c2, k=3, s=1, e=0.5):
        super().__init__()
        c_ = int(c2 * e)
        # for lighting
        self.conv_lighting = nn.Sequential(
            GSConv(c1, c_, 1, 1),
            GSConv(c_, c2, 3, 1, act=False))
        self.shortcut = Conv(c1, c2, 1, 1, act=False)

    def forward(self, x):
        return self.conv_lighting(x) + self.shortcut(x)


class DWConv(Conv):
    # Depth-wise convolution class
    def __init__(self, c1, c2, k=1, s=1, act=True):  # ch_in, ch_out, kernel, stride, padding, groups
        super().__init__(c1, c2, k, s, g=math.gcd(c1, c2), act=act)


class VoVGSCSP(nn.Module):
    # VoVGSCSP module with GSBottleneck
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):
        super().__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c1, c_, 1, 1)
        # self.gc1 = GSConv(c_, c_, 1, 1)
        # self.gc2 = GSConv(c_, c_, 1, 1)
        # self.gsb = GSBottleneck(c_, c_, 1, 1)
        self.gsb = nn.Sequential(*(GSBottleneck(c_, c_, e=1.0) for _ in range(n)))
        self.res = Conv(c_, c_, 3, 1, act=False)
        self.cv3 = Conv(2 * c_, c2, 1)  #

    def forward(self, x):
        x1 = self.gsb(self.cv1(x))
        y = self.cv2(x)
        return self.cv3(torch.cat((y, x1), dim=1))


class VoVGSCSPC(VoVGSCSP):
    # cheap VoVGSCSP module with GSBottleneck
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):
        super().__init__(c1, c2)
        c_ = int(c2 * 0.5)  # hidden channels
        self.gsb = GSBottleneckC(c_, c_, 1, 1)


# SE
class SE(nn.Module):
    def __init__(self, c1, ratio=16):
        super(SE, self).__init__()
        self.avgpool = nn.AdaptiveAvgPool2d(1)
        self.l1 = nn.Linear(c1, c1 // ratio, bias=False)
        self.relu = nn.ReLU(inplace=True)
        self.l2 = nn.Linear(c1 // ratio, c1, bias=False)
        self.sig = nn.Sigmoid()

    def forward(self, x):
        b, c, _, _ = x.size()
        y = self.avgpool(x).view(b, c)
        y = self.l1(y)
        y = self.relu(y)
        y = self.l2(y)
        y = self.sig(y)
        y = y.view(b, c, 1, 1)
        return x * y.expand_as(x)



class h_sigmoid(nn.Module):
    def __init__(self, inplace=True):
        super(h_sigmoid, self).__init__()
        self.relu = nn.ReLU6(inplace=inplace)

    def forward(self, x):
        return self.relu(x + 3) / 6


class h_swish(nn.Module):
    def __init__(self, inplace=True):
        super(h_swish, self).__init__()
        self.sigmoid = h_sigmoid(inplace=inplace)

    def forward(self, x):
        return x * self.sigmoid(x)


def rotate_pooling(x, angle_deg, axis='h'):
    """
    可微分旋转池化操作
    输入：
        x : 输入特征图 [N,C,H,W]
        angle_deg : 旋转角度(度) [N,1,1,1]
        axis : 池化方向 ('h'/'w')
    输出：
        旋转对齐后的池化结果 [N,C,H,1] 或 [N,C,1,W]
    """
    N, C, H, W = x.size()
    device = x.device

    # 将角度转换为弧度
    angle_rad = angle_deg * math.pi / 180.0  # [N,1,1,1]

    # 创建旋转网格
    theta = torch.zeros((N, 2, 3), dtype=x.dtype, device=device)
    theta[:, 0, 0] = torch.cos(angle_rad.squeeze())
    theta[:, 0, 1] = -torch.sin(angle_rad.squeeze())
    theta[:, 1, 0] = torch.sin(angle_rad.squeeze())
    theta[:, 1, 1] = torch.cos(angle_rad.squeeze())

    # 生成网格
    grid = F.affine_grid(theta, x.size(), align_corners=False)

    # 旋转特征图
    rotated_x = F.grid_sample(x, grid, mode='bilinear', padding_mode='zeros', align_corners=False)

    # 方向自适应池化
    if axis == 'h':
        pooled = F.adaptive_avg_pool2d(rotated_x, (None, 1))  # [N,C,H,1]
    else:
        pooled = F.adaptive_avg_pool2d(rotated_x, (1, None))  # [N,C,1,W]

    return pooled


# class DeformableAxialConv(nn.Module):
#     def __init__(self, inp, direction='horizontal'):
#         super().__init__()
#         self.direction = direction
#         self.offset_conv = nn.Conv2d(inp, 18, 3, padding=1)  # 3x3卷积生成offset
#         if direction == 'horizontal':
#             self.conv = DeformConv2d(inp, inp // 2, kernel_size=(3, 1), padding=(1, 0))
#         else:
#             self.conv = DeformConv2d(inp, inp // 2, kernel_size=(1, 3), padding=(0, 1))
#
#     def forward(self, x):
#         # 生成offset: [B, 18, H, W] → 每个采样点两个方向的偏移
#         offset = self.offset_conv(x)
#         # 可变形卷积
#         return self.conv(x, offset)


# class DeformableAxialConv(nn.Module):
#     def __init__(self, inp, direction='horizontal'):
#         super().__init__()
#         self.direction = direction
#         self.K = 3  # 卷积核沿轴向的采样点数
#
#         # 动态计算偏移量通道数: K个采样点 × 2(x/y偏移)
#         offset_channels = 2 * self.K
#
#         # 偏移量生成卷积层
#         self.offset_conv = nn.Conv2d(inp,offset_channels,kernel_size=3,padding=1)
#
#         # 可变形卷积配置
#         if direction == 'horizontal':
#             self.conv = DeformConv2d(inp,inp // 2,kernel_size=(self.K, 1),  # 水平轴向卷积
#             padding=(self.K // 2, 0)  # 保持空间尺寸
#             )
#         else:
#             self.conv = DeformConv2d(inp,inp // 2,kernel_size=(1, self.K),  # 垂直轴向卷积
#             padding=(0, self.K // 2)
#             )
#
#     def forward(self, x):
#         offset = self.offset_conv(x)  # 生成偏移量 [B, 2*K, H, W]
#         return self.conv(x, offset)





class MultiScaleDynamicWeight(nn.Module):
    def __init__(self, inp, reduction=16):
        super().__init__()
        # 多尺度特征金字塔
        self.scale1 = nn.AvgPool2d(3, stride=1, padding=1)
        self.scale2 = nn.AvgPool2d(5, stride=1, padding=2)
        self.scale3 = nn.Identity()

        # 动态权重生成网络
        self.weight_net = nn.Sequential(
            nn.Conv2d(inp * 3, inp // reduction, 1),
            nn.ReLU(),
            nn.Conv2d(inp // reduction, 3, 1),  # 三组权重
            nn.Softmax(dim=1)
        )

    def forward(self, x):
        x1 = self.scale1(x)
        x2 = self.scale2(x)
        x3 = self.scale3(x)
        fused = torch.cat([x1, x2, x3], dim=1)
        weights = self.weight_net(fused)  # [B,3,H,W]
        return weights[:, 0:1] * x1 + weights[:, 1:2] * x2 + weights[:, 2:3] * x3

#LongAxisCoordAtt
# class CoordAtt(nn.Module):
#     def __init__(self, inp, reduction=16):
#         super().__init__()
#         self.inp = inp
#         self.reduction = reduction
#
#         # 水平轴向卷积 (3x1)
#         self.h_conv = DeformableAxialConv(inp, direction='horizontal')
#         self.v_conv = DeformableAxialConv(inp, direction='vertical')
#
#         # 动态权重生成网络
#         # self.ms_weight = MultiScaleDynamicWeight(inp, reduction)
#         self.weight_net = nn.Sequential(
#             nn.AdaptiveAvgPool2d(1),  # 全局平均池化
#             nn.Conv2d(inp, inp // reduction, 1),  # 降维
#             nn.ReLU(inplace=True),
#             nn.Conv2d(inp // reduction, 3, 1),  # 输出3组权重
#             nn.Sigmoid()
#         )
#
#         # 通道注意力（修正关键部分）
#         self.channel_att = nn.Sequential(
#             nn.Conv2d(inp, inp // reduction, 1),  # 输入通道调整为inp
#             nn.LayerNorm([inp // reduction, 1, 1]),
#             nn.ReLU(inplace=True),
#             nn.Conv2d(inp // reduction, inp, 1),  # 输出通道与输入一致
#             nn.Sigmoid()
#         )
#
#         self._init_weights()
#
#     def _init_weights(self):
#         # 初始化水平卷积的主卷积和偏移卷积
#         nn.init.kaiming_normal_(self.h_conv.conv.weight,
#                                 mode='fan_out',
#                                 nonlinearity='relu')
#         nn.init.constant_(self.h_conv.conv.bias, 0.0)
#         nn.init.normal_(self.h_conv.offset_conv.weight, mean=0.0, std=0.01)
#         nn.init.constant_(self.h_conv.offset_conv.bias, 0.0)
#
#         # 初始化垂直卷积的主卷积和偏移卷积
#         nn.init.kaiming_normal_(self.v_conv.conv.weight,
#                                 mode='fan_out',
#                                 nonlinearity='relu')
#         nn.init.constant_(self.v_conv.conv.bias, 0.0)
#         nn.init.normal_(self.v_conv.offset_conv.weight, mean=0.0, std=0.01)
#         nn.init.constant_(self.v_conv.offset_conv.bias, 0.0)
#
#         # 动态权重网络初始化
#         nn.init.constant_(self.weight_net[3].bias[0], 0.7)  # 水平权重偏置
#         nn.init.constant_(self.weight_net[3].bias[1], 0.7)  # 垂直权重偏置
#         nn.init.constant_(self.weight_net[3].bias[2], 1.0)  # 通道权重偏置
#
#     def forward(self, x):
#         B, C, H, W = x.size()
#
#         # ========== 轴向特征分解 ==========
#         h_feat = self.h_conv(x)  # [B, C/2, H, W]
#         v_feat = self.v_conv(x)  # [B, C/2, H, W]
#
#         # ========== 动态权重生成 ==========
#         weights = self.weight_net(x)  # [B, 3, 1, 1]
#         h_weight = weights[:, 0].unsqueeze(1)  # [B, 1, 1, 1]
#         v_weight = weights[:, 1].unsqueeze(1)  # [B, 1, 1, 1]
#         c_weight = weights[:, 2].unsqueeze(1)  # [B, 1, 1, 1]
#
#         # ========== 空间注意力 ==========
#         h_att = h_feat * h_weight  # 水平增强 [B, C/2, H, W]
#         v_att = v_feat * v_weight  # 垂直增强 [B, C/2, H, W]
#         spatial_att = torch.cat([h_att, v_att], dim=1)  # [B, C, H, W]
#
#         # ========== 通道注意力（修正部分） ==========
#         # 全局平均池化统一维度
#         h_global = F.adaptive_avg_pool2d(h_feat, (1, 1))  # [B, C/2, 1, 1]
#         v_global = F.adaptive_avg_pool2d(v_feat, (1, 1))  # [B, C/2, 1, 1]
#         channel_feat = torch.cat([h_global, v_global], dim=1)  # [B, C, 1, 1]
#         channel_att = self.channel_att(channel_feat)  # [B, C, 1, 1]
#
#         # ========== 特征融合 ==========
#         out = x * spatial_att  # 空间增强
#         out = out * channel_att * c_weight  # 通道增强
#         return out


#OrientedCoordAtt
# class CoordAtt(nn.Module):
#     """方向敏感的坐标注意力模块（Oriented Coordinate Attention）
#
#     主要改进：
#     1. 引入可学习方向卷积核增强长边响应
#     2. 方向特征与坐标注意力的自适应融合
#     3. 分组卷积降低计算开销
#
#     输入输出维度保持不变，可直接替换原CoordAtt模块
#     """
#
#     def __init__(self, inp, reduction=32, groups=8):
#         super().__init__()
#         self.groups = groups
#
#         # 原坐标注意力组件
#         self.pool_h = nn.AdaptiveAvgPool2d((None, 1))
#         self.pool_w = nn.AdaptiveAvgPool2d((1, None))
#
#         mip = max(8, inp // reduction)
#
#         self.conv1 = nn.Conv2d(inp, mip, 1, bias=False)
#         self.bn1 = nn.BatchNorm2d(mip)
#         self.act = nn.Hardswish()
#
#         self.conv_h = nn.Conv2d(mip, inp, 1, bias=False)
#         self.conv_w = nn.Conv2d(mip, inp, 1, bias=False)
#
#         # 方向感知增强组件
#         self.orient_conv = nn.Conv2d(
#             inp, inp, kernel_size=3,
#             padding=1, groups=self.groups,  # 分组卷积降低计算量
#             bias=False
#         )
#         self.orient_bn = nn.BatchNorm2d(inp)
#
#         # 自适应融合参数
#         self.gamma = nn.Parameter(torch.zeros(1))
#
#         self._init_weights()
#
#     def _init_weights(self):
#         # 方向卷积核特殊初始化
#         nn.init.kaiming_uniform_(self.orient_conv.weight,
#                                  mode='fan_out',
#                                  nonlinearity='relu')
#         # 融合参数初始化
#         nn.init.constant_(self.gamma, 0.2)
#
#     def forward(self, x):
#         identity = x
#
#         # ----------------- 原坐标注意力路径 -----------------
#         n, c, h, w = x.size()
#
#         # 水平池化
#         x_h = self.pool_h(x)  # [B,C,H,1]
#         # 垂直池化
#         x_w = self.pool_w(x).permute(0, 1, 3, 2)  # [B,C,W,1]
#
#         # 拼接与转换
#         y = torch.cat([x_h, x_w], dim=2)
#         y = self.conv1(y)
#         y = self.bn1(y)
#         y = self.act(y)
#
#         # 拆分与恢复维度
#         x_h, x_w = torch.split(y, [h, w], dim=2)
#         x_w = x_w.permute(0, 1, 3, 2)  # [B,mip,1,W]
#
#         # 生成注意力图
#         a_h = self.conv_h(x_h).sigmoid()  # [B,C,H,1]
#         a_w = self.conv_w(x_w).sigmoid()  # [B,C,1,W]
#         coord_att = a_h * a_w
#
#         # ----------------- 方向感知增强路径 -----------------
#         # 分组方向卷积
#         orient_feat = self.orient_conv(x)
#         orient_feat = self.orient_bn(orient_feat)
#
#         # 空间注意力生成
#         orient_att = torch.sigmoid(orient_feat)
#
#         # ----------------- 自适应融合 -----------------
#         fused_att = coord_att + self.gamma * orient_att
#         return identity * fused_att

#DynamicCoordAtt
# class CoordAtt(nn.Module):
#     def __init__(self, inp, reduction=32):
#         super(CoordAtt, self).__init__()
#         self.pool_h = nn.AdaptiveAvgPool2d((None, 1))
#         self.pool_w = nn.AdaptiveAvgPool2d((1, None))
#
#         mip = max(8, inp // reduction)
#
#         self.conv1 = nn.Conv2d(inp, mip, kernel_size=1, stride=1, padding=0)
#         self.bn1 = nn.BatchNorm2d(mip)
#         self.act = h_swish()
#
#         self.conv_h = nn.Conv2d(mip, inp, kernel_size=1, stride=1, padding=0)
#         self.conv_w = nn.Conv2d(mip, inp, kernel_size=1, stride=1, padding=0)
#
#         # 动态角度预测分支
#         self.angle_conv = nn.Sequential(
#             nn.Conv2d(inp, max(16, inp // 8), kernel_size=1),
#             nn.ReLU(inplace=True),
#             nn.AdaptiveAvgPool2d(1),
#             nn.Conv2d(max(16, inp // 8), 1, kernel_size=1)
#         )
#         self.angle_act = nn.Sigmoid()
#
#     def forward(self, x):
#         identity = x
#
#         # 预测动态旋转角度 [0°, 90°]
#         angle_pred = self.angle_act(self.angle_conv(x)) * 90.0  # [N,1,1,1]
#
#         # 动态旋转池化
#         x_h_rot = rotate_pooling(x, angle_pred, axis='h')  # [N,C,H,1]
#         x_w_rot = rotate_pooling(x, angle_pred, axis='w')  # [N,C,1,W]
#
#         # 坐标信息聚合
#         x_w_rot = x_w_rot.permute(0, 1, 3, 2)
#         y = torch.cat([x_h_rot, x_w_rot], dim=2)
#
#         # 注意力生成
#         y = self.conv1(y)
#         y = self.bn1(y)
#         y = self.act(y)
#
#         # 拆分注意力
#         x_h, x_w = torch.split(y, [y.size(2) // 2, y.size(2) // 2], dim=2)
#         x_w = x_w.permute(0, 1, 3, 2)
#
#         # 注意力权重
#         a_h = self.conv_h(x_h).sigmoid()
#         a_w = self.conv_w(x_w).sigmoid()
#
#         # 修改特征重标定公式
#         out = identity * (0.7 * a_w * a_h + 0.3)  # 保留30%原始特征
#
#         # 梯度检查点
#         if torch.is_grad_enabled():
#             # 注册梯度钩子
#             out.register_hook(lambda grad: print(f"CoordAtt梯度范数: {grad.norm().item():.4f}"))
#             a_h.register_hook(lambda grad: print(f"水平注意力梯度: {grad.norm().item():.4f}"))
#             a_w.register_hook(lambda grad: print(f"垂直注意力梯度: {grad.norm().item():.4f}"))
#             angle_pred.register_hook(lambda grad: print(f"角度预测梯度: {grad.norm().item():.4f}"))
#
#         return out



class CoordAtt(nn.Module):
    def __init__(self, inp, reduction=32):
        super(CoordAtt, self).__init__()
        self.pool_h = nn.AdaptiveAvgPool2d((None, 1))
        self.pool_w = nn.AdaptiveAvgPool2d((1, None))

        mip = max(8, inp // reduction)

        self.conv1 = nn.Conv2d(inp, mip, kernel_size=1, stride=1, padding=0)
        self.bn1 = nn.BatchNorm2d(mip)
        self.act = h_swish()

        self.conv_h = nn.Conv2d(mip, inp, kernel_size=1, stride=1, padding=0)
        self.conv_w = nn.Conv2d(mip, inp, kernel_size=1, stride=1, padding=0)

    def forward(self, x):
        identity = x

        n, c, h, w = x.size()
        x_h = self.pool_h(x)
        x_w = self.pool_w(x).permute(0, 1, 3, 2)

        y = torch.cat([x_h, x_w], dim=2)
        y = self.conv1(y)
        y = self.bn1(y)
        y = self.act(y)

        x_h, x_w = torch.split(y, [h, w], dim=2)
        x_w = x_w.permute(0, 1, 3, 2)

        a_h = self.conv_h(x_h).sigmoid()
        a_w = self.conv_w(x_w).sigmoid()

        out = identity * a_w * a_h

        return out


class HybridActivation(nn.Module):
    def __init__(self):
        super().__init__()
        self.beta = nn.Parameter(torch.tensor(0.5))  # Sigmoid占比

    def forward(self, x):
        sigmoid = torch.sigmoid(x)
        swish = x * torch.sigmoid(x)
        return self.beta * sigmoid + (1-self.beta) * swish



# class ECA(nn.Module):
#     """Constructs a ECA module.
#     Args:
#         channel: Number of channels of the input feature map
#         k_size: Adaptive selection of kernel size
#     """
#
#     def __init__(self, channel, k_size=3):
#         super(ECA, self).__init__()
#         self.avg_pool = nn.AdaptiveAvgPool2d(1)
#         self.conv = nn.Conv1d(1, 1, kernel_size=k_size, padding=(k_size - 1) // 2, bias=False)
#         self.sigmoid = nn.Sigmoid()
#
#     def forward(self, x):
#         # feature descriptor on the global spatial information
#         y = self.avg_pool(x)
#
#         # Two different branches of ECA module
#         y = self.conv(y.squeeze(-1).transpose(-1, -2)).transpose(-1, -2).unsqueeze(-1)
#
#         # Multi-scale information fusion
#         y = self.sigmoid(y)
#
#         return x * y.expand_as(x)


class ECA(nn.Module):
    def __init__(self, channel, gamma=2, b=1):  #64
        super(ECA, self).__init__()
        kernel_size = int(abs((math.log(channel,2)+  b)/gamma))  #3
        kernel_size = kernel_size if kernel_size % 2  else kernel_size+1  #3
        padding = kernel_size//2
        self.avg_pool =nn.AdaptiveAvgPool2d(1)
        self.conv = nn.Conv1d(1, 1, kernel_size, padding=padding, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        b, c, h, w = x.size()  #torch.Size([2, 64, 26, 26])
        #变成序列的形式
        avg = self.avg_pool(x).view([b, 1, c])   #torch.Size([2, 64, 1, 1])   torch.Size([2, 1, 64])
        out = self.conv(avg)                     #torch.Size([2, 1, 64])
        out = self.sigmoid(out).view([b, c, 1, 1])  #torch.Size([2, 64, 1, 1])
        return  out * x

#Improved_SC_CoordAtt
# class GC_CoordAtt(nn.Module):
#     def __init__(self, inp, reduction=32):
#         super().__init__()
#         self.pool_h = nn.AdaptiveAvgPool2d((None, 1))
#         self.pool_w = nn.AdaptiveAvgPool2d((1, None))
#
#         # ---- 局部空间约束模块（与原版SC_CoordAtt一致）----
#         self.local_conv = nn.Sequential(
#             nn.Conv2d(inp, inp, 3, padding=1, groups=inp),
#             nn.BatchNorm2d(inp),
#             nn.Sigmoid()
#         )
#
#         # ---- 注意力融合权重生成（核心改进）----
#         self.gate = nn.Sequential(
#             nn.AdaptiveAvgPool2d(1),                # [N, C, 1, 1]
#             nn.Conv2d(inp, max(4, inp//16), 1),      # 压缩通道
#             nn.ReLU(),
#             nn.Conv2d(max(4, inp//16), 3, 1),        # 输出3个权重分支
#             nn.Softmax(dim=1)                        # 权重归一化
#         )
#
#         # ---- 原坐标注意力分支参数 ----
#         mip = max(8, inp // reduction)
#         self.conv1 = nn.Conv2d(inp, mip, 1)
#         self.bn1 = nn.BatchNorm2d(mip)
#         self.act = nn.Hardswish()
#
#         self.conv_h = nn.Conv2d(mip, inp, 1)
#         self.conv_w = nn.Conv2d(mip, inp, 1)
#
#     def forward(self, x):
#         identity = x
#
#         # ========== 局部空间约束 ==========
#         spatial_mask = self.local_conv(x)  # [N, C, H, W]
#
#         # ========== 原坐标注意力计算 ==========
#         n, c, h, w = x.size()
#         # 横向池化
#         x_h = self.pool_h(x)               # [N, C, H, 1]
#         # 纵向池化（转置后拼接）
#         x_w = self.pool_w(x).permute(0, 1, 3, 2)  # [N, C, W, 1]
#         y = torch.cat([x_h, x_w], dim=2)   # [N, C, H+W, 1]
#         # 通道压缩与激活
#         y = self.conv1(y)                  # [N, mip, H+W, 1]
#         y = self.bn1(y)
#         y = self.act(y)
#         # 拆分并恢复维度
#         x_h, x_w = torch.split(y, [h, w], dim=2)  # x_h: [N, mip, H, 1], x_w: [N, mip, W, 1]
#         x_w = x_w.permute(0, 1, 3, 2)      # [N, mip, 1, W]
#         # 生成注意力权重
#         a_h = self.conv_h(x_h).sigmoid()   # [N, C, H, 1]
#         a_w = self.conv_w(x_w).sigmoid()   # [N, C, 1, W]
#         coord_att = a_h * a_w              # [N, C, H, W]
#
#         # ========== 动态注意力融合（核心改进） ==========
#         # 生成三组注意力权重 [N, 3, 1, 1]
#         gate_weights = self.gate(x)
#         # 维度扩展以便广播 [N, 3, 1, 1] -> [N, 3, 1, 1, 1]
#         gate_weights = gate_weights.unsqueeze(-1)
#         # 加权融合公式：w1*coord_att + w2*spatial_mask + w3*identity
#         weighted_att = (
#             gate_weights[:, 0] * coord_att +
#             gate_weights[:, 1] * spatial_mask +
#             gate_weights[:, 2] * torch.ones_like(coord_att)
#         )  # [N, C, H, W]
#
#         # ========== 最终输出 ==========
#         out = identity * weighted_att.squeeze(-1)
#         return out


class SCCA(nn.Module):
    def __init__(self, inp, reduction=32):
        super().__init__()
        self.pool_h = nn.AdaptiveAvgPool2d((None, 1))
        self.pool_w = nn.AdaptiveAvgPool2d((1, None))

        # 增强局部特征建模
        self.local_conv = nn.Sequential(
            nn.Conv2d(inp, inp, 3, padding=1, groups=inp),  # 深度卷积
            nn.BatchNorm2d(inp),
            nn.Sigmoid()  # 生成空间掩码
        )

        mip = max(8, inp // reduction)
        self.conv1 = nn.Conv2d(inp, mip, 1)
        self.bn1 = nn.BatchNorm2d(mip)
        self.act = nn.Hardswish()

        self.conv_h = nn.Conv2d(mip, inp, 1)
        self.conv_w = nn.Conv2d(mip, inp, 1)

    def forward(self, x):
        identity = x

        # 空间约束掩码
        spatial_mask = self.local_conv(x)  # 强调目标区域

        # 原坐标注意力
        n, c, h, w = x.size()
        x_h = self.pool_h(x)
        x_w = self.pool_w(x).permute(0, 1, 3, 2)
        y = torch.cat([x_h, x_w], dim=2)
        y = self.conv1(y)
        y = self.bn1(y)
        y = self.act(y)

        x_h, x_w = torch.split(y, [h, w], dim=2)
        a_h = self.conv_h(x_h).sigmoid()
        a_w = self.conv_w(x_w.permute(0, 1, 3, 2)).sigmoid()

        # 应用空间约束
        out = identity * a_w * a_h * spatial_mask
        return out


# Backward-compatible alias: checkpoints trained under the original class name still load.
GC_CoordAtt = SCCA

class DeformableAxialConv(nn.Module):
    """可变形轴向卷积模块（水平/垂直方向）"""

    def __init__(self, inp, direction='horizontal'):
        super().__init__()
        self.direction = direction
        self.K = 3  # 卷积核沿轴向的采样点数

        # 动态偏移量生成（每个采样点2个偏移量）
        self.offset_conv = nn.Conv2d(inp, 2 * self.K, kernel_size=3, padding=1)

        # 可变形卷积配置
        if direction == 'horizontal':
            self.conv = DeformConv2d(inp, inp, kernel_size=(self.K, 1), padding=(self.K // 2, 0))
        else:
            self.conv = DeformConv2d(inp, inp, kernel_size=(1, self.K), padding=(0, self.K // 2))

    def forward(self, x):
        offset = self.offset_conv(x)
        return self.conv(x, offset)


#DeformableCoordAtt
class DeformableCoordAtt(nn.Module):
    """融合可变形轴向卷积的坐标注意力模块"""

    def __init__(self, inp, reduction=32):
        super().__init__()
        self.inp = inp
        self.reduction = reduction

        # ========== 可变形轴向特征提取 ==========
        self.deform_h = DeformableAxialConv(inp, direction='horizontal')
        self.deform_w = DeformableAxialConv(inp, direction='vertical')

        # ========== 原坐标注意力组件 ==========
        self.pool_h = nn.AdaptiveAvgPool2d((None, 1))  # 保持H维度
        self.pool_w = nn.AdaptiveAvgPool2d((1, None))  # 保持W维度

        mip = max(8, inp // reduction)
        self.conv1 = nn.Conv2d(inp, mip, kernel_size=1)
        self.bn1 = nn.BatchNorm2d(mip)
        self.act = nn.Hardswish()

        self.conv_h = nn.Conv2d(mip, inp, kernel_size=1)
        self.conv_w = nn.Conv2d(mip, inp, kernel_size=1)

        self._init_weights()

    def _init_weights(self):
        # 可变形卷积初始化
        for m in [self.deform_h, self.deform_w]:
            nn.init.kaiming_normal_(m.conv.weight, mode='fan_out', nonlinearity='relu')
            nn.init.normal_(m.offset_conv.weight, mean=0.0, std=0.01)
            nn.init.constant_(m.conv.weight.data[m.conv.in_channels:], 0.0)  # 残差初始化

        # 注意力分支初始化
        nn.init.kaiming_normal_(self.conv1.weight, mode='fan_out')
        nn.init.constant_(self.conv_h.weight, 0.0)
        nn.init.constant_(self.conv_w.weight, 0.0)

    def forward(self, x):
        identity = x
        B, C, H, W = x.size()

        # 水平分支（保持不变）
        x_h = self.pool_h(x)  # [B, C, H, 1]

        # 垂直分支（关键修正）
        x_w = self.pool_w(x)  # [B, C, 1, W]
        x_w = x_w.permute(0, 1, 3, 2)  # [B, C, W, 1]

        # 拼接时对齐维度
        y = torch.cat([x_h, x_w], dim=3)  # dim=3拼接 → [B, C, H+W, 1]
        y = y.permute(0, 1, 3, 2)  # [B, C, 1, H+W] → 适应后续卷积

        y = self.conv1(y)
        y = self.bn1(y)
        y = self.act(y)

        # 拆分时调整维度
        y = y.permute(0, 1, 3, 2)  # [B, C, H+W, 1] → [B, C, 1, H+W]
        x_h, x_w = torch.split(y, [H, W], dim=2)

        # 恢复垂直分支维度
        x_w = x_w.permute(0, 1, 3, 2)

        a_h = self.conv_h(x_h).sigmoid()
        a_w = self.conv_w(x_w).sigmoid()

        return identity * a_w * a_h



class AKConv(nn.Module):
    def __init__(self, inc, outc, num_param=5, stride=1, bias=None):
        super(AKConv, self).__init__()
        self.num_param = num_param
        self.stride = stride
        self.conv = nn.Sequential(nn.Conv2d(inc, outc, kernel_size=(num_param, 1), stride=(num_param, 1), bias=bias),
                                  nn.BatchNorm2d(outc),
                                  nn.SiLU())  # the conv adds the BN and SiLU to compare original Conv in YOLOv5.
        self.p_conv = nn.Conv2d(inc, 2 * num_param, kernel_size=3, padding=1, stride=stride)
        nn.init.constant_(self.p_conv.weight, 0)
        # self.p_conv.register_full_backward_hook(self._set_lr)

    @staticmethod
    def _set_lr(module, grad_input, grad_output):
        grad_input = (grad_input[i] * 0.1 for i in range(len(grad_input)))
        grad_output = (grad_output[i] * 0.1 for i in range(len(grad_output)))

    def forward(self, x):
        # N is num_param.
        offset = self.p_conv(x)
        dtype = offset.data.type()
        N = offset.size(1) // 2
        # (b, 2N, h, w)
        p = self._get_p(offset, dtype)

        # (b, h, w, 2N)
        p = p.contiguous().permute(0, 2, 3, 1)
        q_lt = p.detach().floor()
        q_rb = q_lt + 1

        q_lt = torch.cat([torch.clamp(q_lt[..., :N], 0, x.size(2) - 1), torch.clamp(q_lt[..., N:], 0, x.size(3) - 1)],
                         dim=-1).long()
        q_rb = torch.cat([torch.clamp(q_rb[..., :N], 0, x.size(2) - 1), torch.clamp(q_rb[..., N:], 0, x.size(3) - 1)],
                         dim=-1).long()
        q_lb = torch.cat([q_lt[..., :N], q_rb[..., N:]], dim=-1)
        q_rt = torch.cat([q_rb[..., :N], q_lt[..., N:]], dim=-1)

        # clip p
        p = torch.cat([torch.clamp(p[..., :N], 0, x.size(2) - 1), torch.clamp(p[..., N:], 0, x.size(3) - 1)], dim=-1)

        # bilinear kernel (b, h, w, N)
        g_lt = (1 + (q_lt[..., :N].type_as(p) - p[..., :N])) * (1 + (q_lt[..., N:].type_as(p) - p[..., N:]))
        g_rb = (1 - (q_rb[..., :N].type_as(p) - p[..., :N])) * (1 - (q_rb[..., N:].type_as(p) - p[..., N:]))
        g_lb = (1 + (q_lb[..., :N].type_as(p) - p[..., :N])) * (1 - (q_lb[..., N:].type_as(p) - p[..., N:]))
        g_rt = (1 - (q_rt[..., :N].type_as(p) - p[..., :N])) * (1 + (q_rt[..., N:].type_as(p) - p[..., N:]))

        # resampling the features based on the modified coordinates.
        x_q_lt = self._get_x_q(x, q_lt, N)
        x_q_rb = self._get_x_q(x, q_rb, N)
        x_q_lb = self._get_x_q(x, q_lb, N)
        x_q_rt = self._get_x_q(x, q_rt, N)

        # bilinear
        x_offset = g_lt.unsqueeze(dim=1) * x_q_lt + \
                   g_rb.unsqueeze(dim=1) * x_q_rb + \
                   g_lb.unsqueeze(dim=1) * x_q_lb + \
                   g_rt.unsqueeze(dim=1) * x_q_rt

        x_offset = self._reshape_x_offset(x_offset, self.num_param)
        out = self.conv(x_offset)

        return out

    # generating the inital sampled shapes for the AKConv with different sizes.
    def _get_p_n(self, N, dtype):
        base_int = round(math.sqrt(self.num_param))
        row_number = self.num_param // base_int
        mod_number = self.num_param % base_int
        p_n_x, p_n_y = torch.meshgrid(
            torch.arange(0, row_number),
            torch.arange(0, base_int))
        p_n_x = torch.flatten(p_n_x)
        p_n_y = torch.flatten(p_n_y)
        if mod_number > 0:
            mod_p_n_x, mod_p_n_y = torch.meshgrid(
                torch.arange(row_number, row_number + 1),
                torch.arange(0, mod_number))

            mod_p_n_x = torch.flatten(mod_p_n_x)
            mod_p_n_y = torch.flatten(mod_p_n_y)
            p_n_x, p_n_y = torch.cat((p_n_x, mod_p_n_x)), torch.cat((p_n_y, mod_p_n_y))
        p_n = torch.cat([p_n_x, p_n_y], 0)
        p_n = p_n.view(1, 2 * N, 1, 1).type(dtype)
        return p_n

    # no zero-padding
    def _get_p_0(self, h, w, N, dtype):
        p_0_x, p_0_y = torch.meshgrid(
            torch.arange(0, h * self.stride, self.stride),
            torch.arange(0, w * self.stride, self.stride))

        p_0_x = torch.flatten(p_0_x).view(1, 1, h, w).repeat(1, N, 1, 1)
        p_0_y = torch.flatten(p_0_y).view(1, 1, h, w).repeat(1, N, 1, 1)
        p_0 = torch.cat([p_0_x, p_0_y], 1).type(dtype)

        return p_0

    def _get_p(self, offset, dtype):
        N, h, w = offset.size(1) // 2, offset.size(2), offset.size(3)

        # (1, 2N, 1, 1)
        p_n = self._get_p_n(N, dtype)
        # (1, 2N, h, w)
        p_0 = self._get_p_0(h, w, N, dtype)
        p = p_0 + p_n + offset
        return p

    def _get_x_q(self, x, q, N):
        b, h, w, _ = q.size()
        padded_w = x.size(3)
        c = x.size(1)
        # (b, c, h*w)
        x = x.contiguous().view(b, c, -1)

        # (b, h, w, N)
        index = q[..., :N] * padded_w + q[..., N:]  # offset_x*w + offset_y
        # (b, c, h*w*N)
        index = index.contiguous().unsqueeze(dim=1).expand(-1, c, -1, -1, -1).contiguous().view(b, c, -1)

        x_offset = x.gather(dim=-1, index=index).contiguous().view(b, c, h, w, N)

        return x_offset

    #  Stacking resampled features in the row direction.
    @staticmethod
    def _reshape_x_offset(x_offset, num_param):
        b, c, h, w, n = x_offset.size()
        # using Conv3d
        # x_offset = x_offset.permute(0,1,4,2,3), then Conv3d(c,c_out, kernel_size =(num_param,1,1),stride=(num_param,1,1),bias= False)
        # using 1 × 1 Conv
        # x_offset = x_offset.permute(0,1,4,2,3), then, x_offset.view(b,c×num_param,h,w)  finally, Conv2d(c×num_param,c_out, kernel_size =1,stride=1,bias= False)
        # using the column conv as follow， then, Conv2d(inc, outc, kernel_size=(num_param, 1), stride=(num_param, 1), bias=bias)

        x_offset = rearrange(x_offset, 'b c h w n -> b c (h n) w')
        return x_offset
