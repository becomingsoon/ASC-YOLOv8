"""Train ASC-YOLOv8 on a rotated (OBB) book spine dataset.

Usage:
    python scripts/train_asc.py path/to/book-spine.yaml [epochs]

Reproduces the configuration of the paper:
    task=obb  imgsz=1024  batch=4  optimizer=auto (AdamW)  close_mosaic=10
    epochs=500  (default)  pretrained = yolov8n-obb weights
"""
import os
import sys

from ultralytics import YOLO

HERE = os.path.dirname(os.path.abspath(__file__))
CFG = os.path.join(os.path.dirname(HERE), "configs", "YOLOv8_SCCA3+ADOWN.yaml")

data = sys.argv[1] if len(sys.argv) > 1 else "book-spine.yaml"
epochs = int(sys.argv[2]) if len(sys.argv) > 2 else 500

model = YOLO(CFG)  # builds the ASC-YOLOv8 network (scale n is used by default)
model.train(
    data=data,
    epochs=epochs,
    imgsz=1024,
    batch=4,
    device=0,
    workers=4,
    optimizer="auto",
    close_mosaic=10,
    patience=100,
    pretrained=True,
    project="runs",
    name="asc-yolov8",
)
