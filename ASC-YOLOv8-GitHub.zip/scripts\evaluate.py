"""Evaluate ASC-YOLOv8 (or any OBB weight) on a dataset and print P/R/mAP50/mAP50-95 + FPS.

Usage:
    python scripts/evaluate.py weights.pt path/to/book-spine.yaml [imgsz]
Example:
    python scripts/evaluate.py runs/asc-yolov8/weights/best.pt path/to/book-spine.yaml 1024
"""
import sys

from ultralytics import YOLO


def evaluate(weights: str, data: str, imgsz: int = 1024, batch: int = 4):
    model = YOLO(weights)
    r = model.val(data=data, imgsz=imgsz, batch=batch, verbose=False, plots=False)
    s = r.speed
    fps = 1000.0 / (s["preprocess"] + s["inference"] + s["postprocess"])
    print("%-34s P=%7.3f  R=%7.3f  mAP50=%7.3f  mAP50-95=%7.3f  |  %6.1f FPS (imgsz=%d)"
          % (weights, r.box.mp, r.box.mr, r.box.map50, r.box.map, fps, imgsz))
    return r


if __name__ == "__main__":
    if len(sys.argv) < 3:
        sys.exit(__doc__)
    w = sys.argv[1]
    d = sys.argv[2]
    sz = int(sys.argv[3]) if len(sys.argv) > 3 else 1024
    evaluate(w, d, sz)
